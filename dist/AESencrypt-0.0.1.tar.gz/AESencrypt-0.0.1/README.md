AESencrypter *
=========

ahmadHashMap is a cross-platform hashing/mapping Python module for human beings. Used to simulate a Python dictionary.


Install ahmadHashMap on your system using :

pip install AESencrypt

Import ahmadHashMap into your project using :

import AESencrypter

Example of creating and using instance of hashMap:

 import AESencrypter



 mAESencrypter.create()


*currently only working with python2 due to dependencies
