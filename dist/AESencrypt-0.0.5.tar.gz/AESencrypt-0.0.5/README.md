AESencrypter
=========

AESencrypter is a cross-platform hashing/mapping Python module for human beings. Used to simulate a Python dictionary.


Install AESencrypter on your system using :

pip install AESencrypt

Import AESencrypter into your project using :

import AESencrypter

Example of creating and using instance of hashMap:

import AESencrypter

AESencrypter.create()
